import * as THREE from 'three';

const $ = (id) => document.getElementById(id);
const game = $('game');
const isTouch = matchMedia('(pointer: coarse)').matches;
let renderer, scene, camera, player, clock, running=false, paused=false, started=false;
let moveX=0, moveY=0, yaw=0, pitch=0.22, nearTerminal=false, objectiveStage=0, audioCtx=null, masterGain=null;
const colliders=[]; const interactables=[]; const keys={};
const SAVE_KEY='project-zero-save-v1';

function mat(color, roughness=.8, metalness=0, emissive=0x000000, intensity=0){return new THREE.MeshStandardMaterial({color,roughness,metalness,emissive,emissiveIntensity:intensity});}
function box(parent,x,y,z,sx,sy,sz,material){const m=new THREE.Mesh(new THREE.BoxGeometry(sx,sy,sz),material);m.position.set(x,y,z);m.castShadow=true;m.receiveShadow=true;parent.add(m);return m;}
function cylinder(parent,x,y,z,rt,rb,h,material,segments=10){const m=new THREE.Mesh(new THREE.CylinderGeometry(rt,rb,h,segments),material);m.position.set(x,y,z);m.castShadow=true;parent.add(m);return m;}
function addCollider(x,z,w,d){colliders.push({x,z,w,d});}
function makeBuilding(x,z,w,d,h,seed){
  const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);
  const concrete=[0x29343c,0x343c43,0x222e38,0x3a4145][seed%4];
  const shell=mat(concrete,.94);const dark=mat(0x111c25,.8);const glass=mat(0x142c38,.22,.65,0x0a2430,.3);const glow=mat(0x68d9d5,.25,.25,0x2ccbc5,2.1);
  box(g,0,h/2,0,w,h,d,shell);
  box(g,0,h*.52,d/2+.025,w*.82,h*.025,.06,dark);
  const floors=Math.max(2,Math.floor(h/3.1));
  for(let f=0;f<floors;f++){
    const yy=1.15+f*2.85;
    for(let c=0;c<Math.max(2,Math.floor(w/1.65));c++){
      const xx=-w/2+.85+c*1.65;if(xx>w/2-.5)continue;
      const lit=((seed*13+f*7+c*3)%9)<3;
      box(g,xx,yy,d/2+.045,.78,1.15,.07,lit?glow:glass);
      box(g,xx,yy-.68,d/2+.06,.92,.09,.11,dark);
    }
  }
  // Architectural ribs, rooftop machinery and a cyan vertical identity strip.
  for(let r=-1;r<=1;r+=2)box(g,r*(w/2-.16),h/2,d/2+.1,.16,h,.16,dark);
  box(g,w*.32,h*.58,d/2+.12,.055,h*.5,.04,glow);
  box(g,0,h+.18,0,w*.78,.36,d*.76,dark);
  for(let k=0;k<3;k++){const px=(k-1)*w*.22;box(g,px,h+.5,0,.5,.42,.5,mat(0x1c2933,.7,.35));cylinder(g,px,h+.78,0,.08,.08,.12,glow,8);}
  // Recessed street-level doorway.
  box(g,0,1.25,d/2+.055,1.45,2.5,.12,dark);
  box(g,0,2.55,d/2+.13,1.5,.08,.08,glow);
  addCollider(x,z,w*.91,d*.91);
}
function makeStreetLight(x,z){
 const g=new THREE.Group();g.position.set(x,0,z);scene.add(g);const metal=mat(0x273944,.55,.65);const light=mat(0x8debe6,.25,.1,0x65e5df,3);
 cylinder(g,0,2.1,0,.055,.075,4.2,metal,8);box(g,.38,4.15,0,.85,.07,.09,metal);box(g,.75,4.04,0,.42,.08,.28,light);const p=new THREE.PointLight(0x72deda,.7,8,2);p.position.set(.72,3.9,0);g.add(p);
}
function makeCar(x,z,rot=0){const g=new THREE.Group();g.position.set(x,0,z);g.rotation.y=rot;scene.add(g);const body=mat(0x303e49,.42,.7),glass=mat(0x0b1d29,.18,.8),tire=mat(0x080c10,1);box(g,0,.65,0,2.15,.65,4.2,body);box(g,0,1.18,-.18,1.75,.72,2.1,glass);for(const xx of [-.92,.92])for(const zz of [-1.35,1.35])cylinder(g,xx,.38,zz,.38,.38,.2,tire,12).rotation.z=Math.PI/2;for(const xx of [-.72,.72])box(g,xx,.72,2.12,.25,.18,.05,mat(0x79deda,.2,0,0x43d6d0,2));addCollider(x,z,2.25,4.3);}
function makeLampPost(x,z){makeStreetLight(x,z);}
function createPlayer(){
 // Original stylized field-explorer silhouette built from articulated-looking armor pieces.
 const root=new THREE.Group();scene.add(root);root.position.set(0,0,7);
 const suit=mat(0x17232e,.72,.25), armor=mat(0x344653,.48,.5), cloth=mat(0x101820,.95), cyan=mat(0x6ce0dc,.28,.3,0x3bcac4,1.4), skin=mat(0x9b8273,.85), visor=mat(0x0a202a,.12,.8,0x2c9eaa,.55);
 const torso=new THREE.Group();root.add(torso);torso.position.y=1.35;
 const chest=box(torso,0,0,0,.78,.86,.42,suit);box(torso,0,.15,.225,.53,.34,.055,armor);box(torso,0,-.2,.24,.25,.08,.045,cyan);
 box(torso,-.43,.2,0,.2,.42,.38,armor);box(torso,.43,.2,0,.2,.42,.38,armor);
 // Backpack and radio antenna.
 box(torso,0,.08,-.34,.55,.72,.22,armor);box(torso,.22,.48,-.35,.035,.32,.035,cyan);
 const head=new THREE.Group();head.position.set(0,.68,.015);torso.add(head);cylinder(head,0,.12,0,.19,.2,.36,skin,12);const helmet=new THREE.Mesh(new THREE.SphereGeometry(.27,16,12),armor);helmet.position.y=.28;helmet.scale.set(1,1.1,1);head.add(helmet);box(head,0,.27,.22,.34,.18,.055,visor);box(head,0,.16,.22,.23,.025,.035,cyan);
 const limbs=[];
 function limb(x,y,len,width,upperMat,lowerMat,arm=false){const pivot=new THREE.Group();pivot.position.set(x,y,0);root.add(pivot);box(pivot,0,-len*.25,0,width,len*.5,width,upperMat);const joint=new THREE.Group();joint.position.y=-len*.5;pivot.add(joint);cylinder(joint,0,0,0,width*.42,width*.42,width*.5,armor,10);box(joint,0,-len*.25,0,width*.78,len*.5,width*.78,lowerMat);if(!arm){box(joint,0,-len*.49,.04,width*1.2,.13,width*1.45,armor);}else{box(joint,0,-len*.49,.03,width*.8,.16,width*.9,armor);}limbs.push({pivot,joint,phase:arm?(x<0?0:Math.PI): (x<0?Math.PI:0),arm});}
 limb(-.53,.98,.48,.24,armor,suit,true);limb(.53,.98,.48,.24,armor,suit,true);limb(-.23,.93,.55,.29,suit,cloth,false);limb(.23,.93,.55,.29,suit,cloth,false);
 root.userData={torso,limbs};return root;
}
function createWorld(){
 scene=new THREE.Scene();scene.background=new THREE.Color(0x111e2b);scene.fog=new THREE.FogExp2(0x111e2b,.022);
 camera=new THREE.PerspectiveCamera(65,innerWidth/innerHeight,.1,180);
 renderer=new THREE.WebGLRenderer({antialias:!isTouch,alpha:false,powerPreference:'high-performance'});renderer.setPixelRatio(Math.min(devicePixelRatio,isTouch?1.35:1.8));renderer.setSize(innerWidth,innerHeight);renderer.shadowMap.enabled=!isTouch;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.outputColorSpace=THREE.SRGBColorSpace;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;game.appendChild(renderer.domElement);
 const hemi=new THREE.HemisphereLight(0x9bb9ca,0x141b24,1.25);scene.add(hemi);const moon=new THREE.DirectionalLight(0x91b9d0,1.6);moon.position.set(-18,32,12);moon.castShadow=!isTouch;moon.shadow.mapSize.set(1024,1024);moon.shadow.camera.left=-35;moon.shadow.camera.right=35;moon.shadow.camera.top=35;moon.shadow.camera.bottom=-35;scene.add(moon);
 const ground= new THREE.Mesh(new THREE.PlaneGeometry(180,180),mat(0x202a31,.98));ground.rotation.x=-Math.PI/2;ground.receiveShadow=true;scene.add(ground);
 // Main avenue, sidewalks, lane markings and rain-darkened insets.
 box(scene,0,.012,0,12,.02,180,mat(0x151e25,.96));
 const sidewalk=mat(0x3a4448,.95),stripe=mat(0x8e9b9d,.8),puddle=mat(0x263d48,.18,.65);
 for(const side of [-1,1]){box(scene,side*7,.09,0,2.1,.18,180,sidewalk);for(let z=-80;z<85;z+=8){box(scene,side*6.8,.19,z,1.55,.015,3,puddle);}}
 for(let z=-85;z<90;z+=9)box(scene,0,.025,z,.13,.025,4,stripe);
 // Dense but bounded city blocks: controlled repetition keeps mobile draw calls reasonable.
 let seed=1;for(let z=-48;z<=48;z+=18){for(const side of [-1,1]){const x=side*(13+(seed%3)*2);makeBuilding(x,z,9+(seed%3),10+(seed%2)*2,13+(seed%5)*2,seed++);}}
 for(let z=-40;z<=44;z+=20){makeStreetLight(-5.6,z);makeStreetLight(5.6,z+8);}
 makeCar(-3.2,-8,.04);makeCar(3.1,24,Math.PI);makeCar(-3.2,49,.02);
 // Broken utility boxes, vents, barriers and illuminated wayfinding markers.
 const crate=mat(0x263742,.82,.3), hazard=mat(0xd5a65b,.7,.1,0x8c571b,.25);
 for(let z=-30;z<50;z+=16){const side=(z%2?1:-1);const x=side*5.1;box(scene,x,.55,z,1.1,1.1,.9,crate);box(scene,x,.95,z+.47,1.05,.08,.04,hazard);}
 // Signal terminal: an obvious, interactive story object.
 const terminal=new THREE.Group();terminal.position.set(1.2,0,-23);scene.add(terminal);const frame=mat(0x263e4a,.4,.7),screen=mat(0x0c2731,.2,.5,0x35d6d1,1.4);
 box(terminal,0,1.1,0,1.15,2.2,.55,frame);box(terminal,0,1.42,.3,.88,.82,.05,screen);box(terminal,0,.45,.31,.55,.08,.06,mat(0x76e6e1,.2,.1,0x4bd8d2,2));for(let y=0;y<2;y++)box(terminal,-.42,.6+y*.18,.31,.12,.035,.035,hazard);
 const beacon=new THREE.PointLight(0x39d9d1,2.4,12,2);beacon.position.set(0,1.8,1.2);terminal.add(beacon);interactables.push({x:1.2,z:-23,r:3.2,type:'terminal'});
 // A distant monolithic tower anchors the skyline.
 const tower=new THREE.Group();tower.position.set(0,0,-74);scene.add(tower);box(tower,0,23,0,15,46,13,mat(0x182832,.55,.35));for(let y=4;y<43;y+=4)box(tower,0,y,6.58,10,.09,.08,mat(0x65d8d3,.2,.3,0x2bc5c0,1.5));
 player=createPlayer();clock=new THREE.Clock();
}
function showToast(text){const t=$('toast');t.textContent=text;t.classList.add('show');setTimeout(()=>t.classList.remove('show'),2300);}
function setObjective(text){$('objective-text').textContent=text;}
function startAudio(){if(!audioCtx){audioCtx=new (window.AudioContext||window.webkitAudioContext)();masterGain=audioCtx.createGain();masterGain.gain.value=.25;masterGain.connect(audioCtx.destination);const osc=audioCtx.createOscillator(),gain=audioCtx.createGain();osc.type='sine';osc.frequency.value=48;gain.gain.value=.035;osc.connect(gain);gain.connect(masterGain);osc.start();}if(audioCtx.state==='suspended')audioCtx.resume();}
function beep(freq=440,duration=.12){if(!audioCtx)return;const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type='sine';o.frequency.setValueAtTime(freq,audioCtx.currentTime);g.gain.setValueAtTime(.001,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.08,audioCtx.currentTime+.02);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g);g.connect(masterGain);o.start();o.stop(audioCtx.currentTime+duration+.03);}
const introLines=[['SINAL DESCONHECIDO','...Se você está ouvindo isso, então o protocolo funcionou.'],['SINAL DESCONHECIDO','Não tente lembrar ainda. A cidade reage quando você lembra.'],['VOCÊ','Quem está falando? O que aconteceu aqui?'],['SINAL DESCONHECIDO','Encontre o terminal na avenida. Depois eu explico. Se ainda houver tempo.']];
function dialogue(lines,onEnd){let i=0;$('dialogue-screen').classList.remove('hidden');function draw(){$('dialogue-speaker').textContent=lines[i][0];$('dialogue-line').textContent=lines[i][1];$('dialogue-next').innerHTML=i===lines.length-1?'FECHAR TRANSMISSÃO <span>↗</span>':'CONTINUAR <span>→</span>';}$('dialogue-next').onclick=()=>{beep(520,.08);i++;if(i>=lines.length){$('dialogue-screen').classList.add('hidden');onEnd?.();}else draw();};draw();}
function interact(){if(!running||paused)return;if(nearTerminal&&objectiveStage===0){objectiveStage=1;setObjective('Acesse o terminal de emergência');dialogue([['SISTEMA LOCAL','IDENTIDADE NÃO RECONHECIDA.'],['SISTEMA LOCAL','ARQUIVO DE MEMÓRIA CORROMPIDO. 1 REGISTRO RECUPERÁVEL.'],['SINAL DESCONHECIDO','Você chegou. Isso significa que eles ainda não encontraram você.'],['VOCÊ','“Eles”? Quem são eles?'],['SINAL DESCONHECIDO','A resposta está no subsolo. Procure a entrada do metrô.']],()=>{objectiveStage=2;setObjective('Investigue a entrada do metrô');saveGame();showToast('NOVO OBJETIVO REGISTRADO');});beep(700,.2);}else if(nearTerminal&&objectiveStage>0){showToast('O terminal não responde mais.');}else showToast('Nada para interagir aqui.');}
function saveGame(){localStorage.setItem(SAVE_KEY,JSON.stringify({stage:objectiveStage,x:player.position.x,z:player.position.z}));showToast('PROGRESSO SALVO');}
function loadGame(){try{return JSON.parse(localStorage.getItem(SAVE_KEY)||'null')}catch{return null}}
function begin(){startAudio();$('title-screen').classList.add('hidden');$('hud').classList.remove('hidden');running=true;started=true;const s=loadGame();if(s){objectiveStage=s.stage||0;player.position.set(s.x||0,0,s.z||7);setObjective(objectiveStage===0?'Siga o sinal do rádio':objectiveStage===1?'Acesse o terminal de emergência':'Investigue a entrada do metrô');}else{player.position.set(0,0,7);dialogue(introLines,()=>setObjective('Siga o sinal do rádio'));}animate();}
function collides(x,z){for(const c of colliders){if(Math.abs(x-c.x)<c.w/2+.42&&Math.abs(z-c.z)<c.d/2+.42)return true;}return false;}
function update(dt){if(!running||paused)return;const forward=(keys.KeyW||keys.ArrowUp?1:0)-(keys.KeyS||keys.ArrowDown?1:0)-moveY;const strafe=(keys.KeyD||keys.ArrowRight?1:0)-(keys.KeyA||keys.ArrowLeft?1:0)+moveX;const len=Math.hypot(forward,strafe);if(len>.05){const f=forward/Math.max(1,len),s=strafe/Math.max(1,len);const speed=keys.ShiftLeft?6:3.5;const dx=(Math.sin(yaw)*f+Math.cos(yaw)*s)*speed*dt;const dz=(-Math.cos(yaw)*f+Math.sin(yaw)*s)*speed*dt;const nx=player.position.x+dx,nz=player.position.z+dz;if(!collides(nx,player.position.z))player.position.x=nx;if(!collides(player.position.x,nz))player.position.z=nz;player.rotation.y=Math.atan2(dx,-dz);const t=performance.now()*.009;player.userData.limbs.forEach(l=>{l.pivot.rotation.x=Math.sin(t+l.phase)*.55;l.joint.rotation.x=Math.max(0,Math.sin(t+l.phase+1))*.45;});}else player.userData.limbs.forEach(l=>{l.pivot.rotation.x*=.8;l.joint.rotation.x*=.8;});
 const target=new THREE.Vector3(player.position.x+Math.sin(yaw)*-5,2.9+pitch,player.position.z+Math.cos(yaw)*5);camera.position.lerp(target,1-Math.pow(.001,dt));camera.lookAt(player.position.x,1.45,player.position.z);nearTerminal=player.position.distanceTo(new THREE.Vector3(1.2,0,-23))<3.6;$('interaction-hint').classList.toggle('hidden',!nearTerminal);$('interact-btn').style.opacity=nearTerminal?'1':'.45';$('clock').textContent='03:'+String(17+Math.floor(performance.now()/60000)%43).padStart(2,'0');}
function animate(){if(!running)return;requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);update(dt);renderer.render(scene,camera);}
function setQuality(q){const dpr=q==='low'?.85:q==='high'?Math.min(devicePixelRatio,2):Math.min(devicePixelRatio,1.35);renderer.setPixelRatio(dpr);renderer.shadowMap.enabled=q==='high'&&!isTouch;renderer.setSize(innerWidth,innerHeight);}
function openPause() {paused=true;$('pause-screen').classList.remove('hidden');}
function closePause(){paused=false;$('pause-screen').classList.add('hidden');}
$('start-btn').onclick=begin;$('continue-btn').onclick=begin;$('pause-btn').onclick=openPause;$('resume-btn').onclick=closePause;$('save-btn').onclick=saveGame;$('title-btn').onclick=()=>{saveGame();running=false;paused=false;$('pause-screen').classList.add('hidden');$('hud').classList.add('hidden');$('title-screen').classList.remove('hidden');};$('interact-btn').onclick=interact;$('quality').onchange=e=>setQuality(e.target.value);$('volume').oninput=e=>{if(masterGain)masterGain.gain.value=Number(e.target.value)/100*.38;};
window.addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='KeyE'||e.code==='Enter')interact();if(e.code==='Escape'){paused?closePause():openPause();}});window.addEventListener('keyup',e=>keys[e.code]=false);
let lookPointer=null,lastX=0,lastY=0;window.addEventListener('pointermove',e=>{if(lookPointer!==e.pointerId||paused)return;const dx=e.clientX-lastX,dy=e.clientY-lastY;lastX=e.clientX;lastY=e.clientY;yaw-=dx*.006;pitch=THREE.MathUtils.clamp(pitch-dy*.003,-.1,.8);});window.addEventListener('pointerup',e=>{if(e.pointerId===lookPointer)lookPointer=null;});
const joy=$('joystick'),stick=$('stick');let joyId=null;function joyMove(e){const r=joy.getBoundingClientRect(),cx=r.left+r.width/2,cy=r.top+r.height/2;let dx=e.clientX-cx,dy=e.clientY-cy;const d=Math.hypot(dx,dy),max=38;if(d>max){dx=dx/d*max;dy=dy/d*max;}stick.style.transform=`translate(${dx}px,${dy}px)`;moveX=dx/max;moveY=dy/max;}
joy.addEventListener('pointerdown',e=>{joyId=e.pointerId;joy.setPointerCapture(joyId);joyMove(e);});joy.addEventListener('pointermove',e=>{if(e.pointerId===joyId)joyMove(e);});function joyEnd(){joyId=null;moveX=moveY=0;stick.style.transform='translate(0,0)';}joy.addEventListener('pointerup',joyEnd);joy.addEventListener('pointercancel',joyEnd);
window.addEventListener('resize',()=>{if(!renderer)return;camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);setQuality($('quality').value);});
createWorld();renderer.domElement.addEventListener('pointerdown',e=>{if(!isTouch||e.clientX<innerWidth*.48)return;lookPointer=e.pointerId;lastX=e.clientX;lastY=e.clientY;});const saved=loadGame();if(saved)$('continue-btn').classList.remove('hidden');$('loading').style.opacity='0';setTimeout(()=>$('loading').remove(),650);
