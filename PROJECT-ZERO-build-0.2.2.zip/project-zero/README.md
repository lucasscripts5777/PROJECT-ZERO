# PROJECT: ZERO — Build 0.2.1

Correção de interface para celulares: menu principal rolável em telas retrato, introdução e configurações com rolagem, áreas seguras do Android respeitadas e botões preparados para toque. O botão ENTENDI agora recebe eventos de toque (a camada da introdução tinha herdado `pointer-events: none`).

Projeto web 3D com Three.js e física Cannon-es. Esta versão ainda é uma etapa inicial jogável, não um jogo AAA completo.

## Build

Extraia o ZIP, entre na pasta `project-zero`, execute `npm install` e `npm run build`. Para Android, use Capacitor e o workflow em `.github/workflows/PROJECT-ZERO-android-apk.yml`.
