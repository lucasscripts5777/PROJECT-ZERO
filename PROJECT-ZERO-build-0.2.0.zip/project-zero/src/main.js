
import * as THREE from 'three';
import * as CANNON from 'cannon-es';
import './style.css';

const app=document.querySelector('#app');
app.innerHTML=`
<div id="world"></div><div id="screen">
<section id="mainMenu"><div id="menuCard"><div class="eyebrow">LC ENTERTAINMENT apresenta</div><div class="logo">PROJECT<span>:</span><br>ZERO</div><div class="subtitle">O SINAL NÃO DEVERIA EXISTIR</div>
<button class="menuBtn primary" id="start">▶ &nbsp; NOVO JOGO</button><button class="menuBtn" id="continue">↻ &nbsp; CONTINUAR</button><button class="menuBtn" id="openSettings">⚙ &nbsp; CONFIGURAÇÕES</button><button class="menuBtn" id="creditsBtn">✦ &nbsp; CRÉDITOS</button></div><div class="credits"><span>IMAGINADO POR LC ENTERTAINMENT</span><span>FEITO POR GPT-MODELS</span></div></section>
<section id="hud"><div class="topline"><span>VÉRTICE // SETOR 07</span><span id="clock">03:17 AM</span></div><div class="objective"><small>OBJETIVO ATUAL</small><strong id="objective">Investigue o sinal de rádio</strong></div><div class="crosshair"></div><div id="prompt">☝ &nbsp; INTERAGIR</div><div id="toast"></div>
<div id="touch"><div class="stick left" id="moveStick"><div class="nub"></div></div><div class="stick right" id="lookStick"><div class="nub"></div></div><button class="action interact" id="interact">☝</button><button class="action run" id="run">»</button><button class="action car" id="enterCar">↗</button><div class="drive" id="drive"><button id="brake">▼</button><button id="gas">▲</button></div></div>
</section>
<section id="settings" class="panel"><div class="settingsBox"><div class="eyebrow">SISTEMA</div><h2>CONFIGURAÇÕES</h2>
<label class="setting">Qualidade gráfica <select id="quality"><option value="low">Econômica</option><option value="medium" selected>Alta</option><option value="high">Muito alta</option></select></label>
<label class="setting">Sensibilidade <input id="sensitivity" type="range" min=".4" max="2.2" step=".1" value="1"></label>
<label class="setting">Campo de visão <input id="fov" type="range" min="65" max="100" value="82"></label>
<label class="setting">Volume geral <input id="volume" type="range" min="0" max="1" step=".05" value=".65"></label>
<label class="setting">Inverter câmera <input id="invert" type="checkbox"></label>
<button class="menuBtn primary" id="closeSettings">VOLTAR</button></div></section>
<section id="pause" class="panel"><div class="dialog"><div class="eyebrow">PROJECT: ZERO</div><h2>PAUSADO</h2><button class="menuBtn primary" id="resume">CONTINUAR</button><button class="menuBtn" id="pauseSettings">CONFIGURAÇÕES</button><button class="menuBtn" id="toMenu">MENU PRINCIPAL</button></div></section>
<section id="chapter"><div class="chapterInner"><small>CAPÍTULO 01 // DESPERTAR</small><h1>O SINAL</h1><p>Você acorda no meio de uma cidade sem energia. Não lembra como chegou aqui. Um rádio chiando repete seu nome — e a transmissão parece vir de algum lugar próximo.</p><button class="menuBtn primary" id="beginChapter">ENTENDI</button></div></section>
</div>`;
const $=id=>document.getElementById(id);
let scene,camera,renderer,world,clock,playerBody,carBody,carMesh,started=false,paused=false,inCar=false,objectiveStage=0;
let yaw=0,pitch=0,move={x:0,y:0},look={x:0,y:0},keys={},nearby=null,audioCtx=null,master=null,engineOsc=null,engineGain=null;
const colliders=[],traffic=[],materials={};
const settings={sensitivity:1,invert:false,volume:.65,quality:'medium'};
const v=(x=0,y=0,z=0)=>new THREE.Vector3(x,y,z);
function mat(color,rough=.8,metal=0){return new THREE.MeshStandardMaterial({color,roughness:rough,metalness:metal});}
function box(w,h,d,m,x,y,z,parent=scene){const o=new THREE.Mesh(new THREE.BoxGeometry(w,h,d),m);o.position.set(x,y,z);o.castShadow=true;o.receiveShadow=true;parent.add(o);return o;}
function makeWindow(x,y,z,w,h,rot=0){const m=new THREE.MeshStandardMaterial({color:0x152a37,emissive:0x163c50,emissiveIntensity:.6,roughness:.35,metalness:.3});const o=box(w,h,.08,m,x,y,z);o.rotation.y=rot;return o;}
function addBuilding(x,z,w,d,h,seed=1){
 const wall=mat(seed%2?0x303d46:0x252f39,.92),trim=mat(0x101c25,.55,.35);
 box(w,h,d,wall,x,h/2,z);box(w+.25,.3,d+.25,trim,x,h+.15,z);
 for(let floor=1;floor<h/3;floor++)for(let col=0;col<Math.max(1,Math.floor(w/2.4));col++){
  const wx=x-w/2+1.2+col*2.4,wy=floor*3;
  if(Math.abs(wx-x)<w/2-.5)makeWindow(wx,wy,z-d/2-.06,1.05,1.45);
 }
 for(let i=0;i<Math.max(2,Math.floor(d/3));i++)makeWindow(x+w/2+.06,2+i*3,z-d/2+1.5+i*2.5,1.05,1.45,Math.PI/2);
 box(w+.5,.16,d+.5,mat(0x121b23),x,.08,z);
}
function makeCar(x,z,color=0x344c59,scale=1){
 const group=new THREE.Group();scene.add(group);group.position.set(x,.45,z);group.scale.setScalar(scale);
 const body=mat(color,.34,.55),glass=new THREE.MeshStandardMaterial({color:0x101f29,metalness:.55,roughness:.18}),rubber=mat(0x080b0e,.95),light=new THREE.MeshStandardMaterial({color:0xbdefff,emissive:0x8bdfff,emissiveIntensity:2});
 box(2.15,.58,4.2,body,0,0,0,group);box(1.65,.75,2.05,glass,0,.58,-.15,group);
 box(2.18,.16,1.1,body,0,.35,1.25,group);box(2.18,.16,1.1,body,0,.35,-1.35,group);
 for(const sx of [-1,1])for(const sz of [-1.35,1.35]){const wheel=new THREE.Mesh(new THREE.CylinderGeometry(.43,.43,.24,18),rubber);wheel.rotation.z=Math.PI/2;wheel.position.set(sx*1.08,-.22,sz);group.add(wheel);}
 for(const sx of [-.7,.7]){box(.32,.15,.08,light,sx,.05,2.13,group);box(.32,.15,.08,mat(0xff342d,.4,0),sx,.05,-2.13,group);}
 return group;
}
function createWorld(){
 scene=new THREE.Scene();scene.background=new THREE.Color(0x07111d);scene.fog=new THREE.FogExp2(0x07111d,.009);
 camera=new THREE.PerspectiveCamera(Number($('fov').value),innerWidth/innerHeight,.1,450);
 renderer=new THREE.WebGLRenderer({antialias:true,alpha:false,powerPreference:'high-performance'});
 renderer.setSize(innerWidth,innerHeight);renderer.setPixelRatio(Math.min(devicePixelRatio,settings.quality==='high'?1.7:1.25));
 renderer.shadowMap.enabled=true;renderer.shadowMap.type=THREE.PCFSoftShadowMap;renderer.toneMapping=THREE.ACESFilmicToneMapping;renderer.toneMappingExposure=1.12;
 $('world').appendChild(renderer.domElement);
 scene.add(new THREE.HemisphereLight(0x8eb8d0,0x12151a,1.05));
 const moon=new THREE.DirectionalLight(0x9dc8ed,1.35);moon.position.set(-40,65,25);moon.castShadow=true;moon.shadow.mapSize.set(1024,1024);scene.add(moon);
 const ground=box(260,.8,260,mat(0x242c31),0,-.5,0);ground.receiveShadow=true;
 // asphalt and lane markings
 box(18,.025,230,mat(0x171d22,.98),0,.015,0);
 for(let z=-110;z<115;z+=10)box(.18,.03,4,mat(0x8e9694),0,.04,z);
 box(1,.035,230,mat(0x9b8f6e),-9,.035,0);box(1,.035,230,mat(0x9b8f6e),9,.035,0);
 for(let z=-100;z<=100;z+=24){addBuilding(-19,z,16,18,12+(Math.abs(z)%3)*3,z+2);addBuilding(20,z+8,18,19,15+(Math.abs(z)%4)*2,z+7);}
 // sidewalks, lamps, cables, street furniture
 const pole=mat(0x101a22,.5,.7),lamp=new THREE.MeshStandardMaterial({color:0xffe3b0,emissive:0xffc66d,emissiveIntensity:2});
 for(let z=-100;z<=100;z+=18)for(const side of [-1,1]){
  const x=side*11.5;box(1.8,.35,16,mat(0x4a5153),x,.18,z);
  const p=box(.18,6,.18,pole,x,3,z);box(.12,.12,2.3,pole,x,5.9,z-side*1.05);
  const bulb=box(.42,.12,.55,lamp,x,5.78,z-side*2);const pl=new THREE.PointLight(0xffc987,.8,13);pl.position.set(x,5.3,z-side*2);scene.add(pl);
 }
 // distant skyline silhouettes
 for(let i=0;i<28;i++){let x=(i%2?1:-1)*(38+(i*7)%55),z=-110+i*8;box(12,18+(i*13)%35,12,mat(0x18232c),x,(18+(i*13)%35)/2,z);}
 // debris, parked cars and moving traffic
 for(let i=0;i<16;i++){let z=-90+i*12;makeCar(i%2?6:-6,z,i%3?0x354b58:0x55504a,.85);}
 for(let i=0;i<4;i++){const c=makeCar(i%2?5:-5,-80-i*34,0x3b5360,.9);traffic.push({mesh:c,zSpeed:7+i*1.2,dir:i%2?1:-1});}
 // mission landmark
 const tower=box(5,14,5,mat(0x263c47,.6,.5),-3,7,-54);box(7,.35,7,mat(0x10202a),-3,14.1,-54);
 const beacon=new THREE.PointLight(0x40dfff,5,35);beacon.position.set(-3,13,-54);scene.add(beacon);
 for(let i=0;i<4;i++){const ring=new THREE.Mesh(new THREE.TorusGeometry(1.1+i*.65,.035,8,48),new THREE.MeshBasicMaterial({color:0x52dff5,transparent:true,opacity:.55}));ring.position.set(-3,11-i*.9,-54);scene.add(ring);}
 // radio console near spawn
 const consoleGroup=new THREE.Group();scene.add(consoleGroup);consoleGroup.position.set(3,0,-12);
 box(1.1,1.1,.55,mat(0x263b47,.4,.5),0,.55,0,consoleGroup);box(.85,.5,.08,new THREE.MeshStandardMaterial({color:0x0b2936,emissive:0x2bc4e7,emissiveIntensity:1.8}),0,.85,.31,consoleGroup);
 consoleGroup.userData.kind='radio';colliders.push({pos:v(3,1,-12),radius:2.5,kind:'radio'});
 // vehicle to enter
 carMesh=makeCar(6,4,0x1d6170,1.05);carMesh.userData.kind='car';colliders.push({pos:v(6,1,4),radius:3.2,kind:'car'});
}
function initPhysics(){
 world=new CANNON.World({gravity:new CANNON.Vec3(0,-9.82,0)});world.broadphase=new CANNON.SAPBroadphase(world);world.allowSleep=true;
 const groundBody=new CANNON.Body({mass:0,shape:new CANNON.Plane()});groundBody.quaternion.setFromEuler(-Math.PI/2,0,0);world.addBody(groundBody);
 playerBody=new CANNON.Body({mass:70,shape:new CANNON.Sphere(.45),position:new CANNON.Vec3(0,1,7),fixedRotation:true,linearDamping:.9});world.addBody(playerBody);
 carBody=new CANNON.Body({mass:1100,shape:new CANNON.Box(new CANNON.Vec3(1.05,.45,2)),position:new CANNON.Vec3(6,.9,4),linearDamping:.22,angularDamping:.8});world.addBody(carBody);
}
function startAudio(){
 if(audioCtx)return;audioCtx=new (window.AudioContext||window.webkitAudioContext)();master=audioCtx.createGain();master.gain.value=settings.volume;master.connect(audioCtx.destination);
 // Original synthesized ambient score: slow atmospheric pads, no external copyrighted music.
 const padGain=audioCtx.createGain();padGain.gain.value=.045;padGain.connect(master);
 [55,82.41,110,164.81].forEach((freq,i)=>{const o=audioCtx.createOscillator();const g=audioCtx.createGain();o.type=i%2?'triangle':'sine';o.frequency.value=freq;o.detune.value=i*4;g.gain.value=.23/(i+1);o.connect(g);g.connect(padGain);o.start();});
 const noise=audioCtx.createBufferSource();const buf=audioCtx.createBuffer(1,audioCtx.sampleRate*2,audioCtx.sampleRate);const data=buf.getChannelData(0);for(let i=0;i<data.length;i++)data[i]=(Math.random()*2-1)*.15;noise.buffer=buf;noise.loop=true;const filter=audioCtx.createBiquadFilter();filter.type='lowpass';filter.frequency.value=380;const ng=audioCtx.createGain();ng.gain.value=.12;noise.connect(filter);filter.connect(ng);ng.connect(master);noise.start();
 engineOsc=audioCtx.createOscillator();engineGain=audioCtx.createGain();engineOsc.type='sawtooth';engineOsc.frequency.value=48;engineGain.gain.value=0;engineOsc.connect(engineGain);engineGain.connect(master);engineOsc.start();
}
function sfx(freq=440,duration=.12,type='sine',vol=.12){if(!audioCtx)return;const o=audioCtx.createOscillator(),g=audioCtx.createGain();o.type=type;o.frequency.setValueAtTime(freq,audioCtx.currentTime);o.frequency.exponentialRampToValueAtTime(Math.max(40,freq*.55),audioCtx.currentTime+duration);g.gain.setValueAtTime(vol*settings.volume,audioCtx.currentTime);g.gain.exponentialRampToValueAtTime(.001,audioCtx.currentTime+duration);o.connect(g);g.connect(master);o.start();o.stop(audioCtx.currentTime+duration);}
function toast(t){$('toast').textContent=t;$('toast').style.display='block';setTimeout(()=>$('toast').style.display='none',2800);}
function showChapter(){ $('chapter').style.display='flex'; }
function begin(){startAudio();$('mainMenu').style.display='none';$('chapter').style.display='none';$('hud').style.display='block';$('touch').style.display='block';started=true;paused=false;clock.start();toast('SINAL DETECTADO // FREQUÊNCIA 107.4');}
function pause(){if(!started)return;paused=true;$('pause').style.display='flex';}
function resume(){$('pause').style.display='none';paused=false;}
function interact(){
 if(inCar){inCar=false;playerBody.position.set(carBody.position.x+2,1,carBody.position.z);carBody.velocity.set(0,0,0);$('drive').style.display='none';$('interact').style.display='grid';return;}
 if(nearby==='radio'){if(objectiveStage===0){objectiveStage=1;$('objective').textContent='Siga o sinal até a torre';toast('RÁDIO: “Você demorou... vá até a torre azul.”');sfx(720,.25,'triangle');}else toast('O rádio repete apenas estática.');}
 else if(nearby==='car'){inCar=true;playerBody.velocity.set(0,0,0);$('drive').style.display='flex';$('interact').style.display='none';toast('VEÍCULO CONECTADO // USE ▲ E ▼');}
 else if(objectiveStage===1&&playerBody.position.distanceTo(new CANNON.Vec3(-3,0,-54))<9){objectiveStage=2;$('objective').textContent='Capítulo concluído — sinal localizado';toast('CAPÍTULO 01 CONCLUÍDO');sfx(880,.4,'sine');}
 else toast('Não há nada para interagir aqui.');
}
function setupControls(){
 document.addEventListener('keydown',e=>{keys[e.code]=true;if(e.code==='Escape')paused?resume():pause();if(e.code==='KeyE'||e.code==='KeyF')interact();});
 document.addEventListener('keyup',e=>keys[e.code]=false);
 let activeTouch=null;
 function stick(el,type){const nub=el.querySelector('.nub');el.addEventListener('pointerdown',e=>{el.setPointerCapture(e.pointerId);activeTouch=e.pointerId;update(e);});el.addEventListener('pointermove',e=>{if(activeTouch===e.pointerId)update(e);});el.addEventListener('pointerup',e=>{if(activeTouch===e.pointerId){activeTouch=null;move[type==='move'?'x':'y']=0;move[type==='move'?'y':'x']=0;nub.style.transform='translate(0,0)';}});function update(e){const r=el.getBoundingClientRect(),dx=(e.clientX-r.left-r.width/2)/(r.width/2),dy=(e.clientY-r.top-r.height/2)/(r.height/2),x=Math.max(-1,Math.min(1,dx)),y=Math.max(-1,Math.min(1,dy));nub.style.transform=`translate(${x*28}px,${y*28}px)`;if(type==='move'){move.x=x;move.y=y;}else{look.x=x;look.y=y;}}}
 stick($('moveStick'),'move');stick($('lookStick'),'look');
 $('interact').onclick=interact;$('enterCar').onclick=interact;$('run').onpointerdown=()=>keys.ShiftLeft=true;$('run').onpointerup=()=>keys.ShiftLeft=false;
 $('gas').onpointerdown=()=>keys.ArrowUp=true;$('gas').onpointerup=()=>keys.ArrowUp=false;$('brake').onpointerdown=()=>keys.ArrowDown=true;$('brake').onpointerup=()=>keys.ArrowDown=false;
 let lookStart=null;renderer.domElement.addEventListener('pointerdown',e=>{if(e.pointerType==='mouse'&&started&&!paused){lookStart={x:e.clientX,y:e.clientY};}});renderer.domElement.addEventListener('pointermove',e=>{if(lookStart){yaw-= (e.clientX-lookStart.x)*.003*settings.sensitivity;pitch-=(e.clientY-lookStart.y)*.003*settings.sensitivity;lookStart={x:e.clientX,y:e.clientY};}});renderer.domElement.addEventListener('pointerup',()=>lookStart=null);
}
function settingsUI(){
 $('openSettings').onclick=()=>{$('settings').style.display='flex';$('mainMenu').style.display='none';};
 $('pauseSettings').onclick=()=>{$('pause').style.display='none';$('settings').style.display='flex';};
 $('closeSettings').onclick=()=>{$('settings').style.display='none';if(started)$('pause').style.display='flex';else $('mainMenu').style.display='flex';};
 $('quality').onchange=e=>{settings.quality=e.target.value;renderer.setPixelRatio(Math.min(devicePixelRatio,e.target.value==='high'?1.7:e.target.value==='medium'?1.25:1));renderer.shadowMap.enabled=e.target.value!=='low';};
 $('sensitivity').oninput=e=>settings.sensitivity=+e.target.value;$('volume').oninput=e=>{settings.volume=+e.target.value;if(master)master.gain.value=settings.volume;};
 $('fov').oninput=e=>{camera.fov=+e.target.value;camera.updateProjectionMatrix();};$('invert').onchange=e=>settings.invert=e.target.checked;
 $('start').onclick=showChapter;$('beginChapter').onclick=begin;$('continue').onclick=()=>{showChapter();};$('resume').onclick=resume;$('toMenu').onclick=()=>{location.reload();};
 $('creditsBtn').onclick=()=>toast('IMAGINADO POR LC ENTERTAINMENT • FEITO POR GPT-MODELS');
}
function update(dt){
 const speed=keys.ShiftLeft?8:4.2;
 if(!inCar){
  const forward=-(move.y||((keys.KeyW||keys.ArrowUp)?1:0)-((keys.KeyS||keys.ArrowDown)?1:0));
  const side=move.x||((keys.KeyD?1:0)-(keys.KeyA?1:0));
  const dir=new CANNON.Vec3(Math.sin(yaw)*forward+Math.cos(yaw)*side,0,-Math.cos(yaw)*forward+Math.sin(yaw)*side);
  if(dir.length()>1)dir.normalize();playerBody.velocity.x=dir.x*speed;playerBody.velocity.z=dir.z*speed;
  if(look.x||look.y){yaw-=look.x*.035*settings.sensitivity;pitch+=(settings.invert?1:-1)*look.y*.025*settings.sensitivity;look.x*=.82;look.y*=.82;}
  camera.position.set(playerBody.position.x,playerBody.position.y+.28,playerBody.position.z);
 }else{
  const throttle=(keys.ArrowUp?1:0)-(keys.ArrowDown?1:0);const fwd=new CANNON.Vec3(Math.sin(yaw),0,-Math.cos(yaw));carBody.velocity.x+=fwd.x*throttle*14*dt;carBody.velocity.z+=fwd.z*throttle*14*dt;
  carBody.velocity.x*=.992;carBody.velocity.z*=.992;const vel=Math.hypot(carBody.velocity.x,carBody.velocity.z);if(vel>.1)yaw=Math.atan2(carBody.velocity.x,-carBody.velocity.z);
  carBody.position.y=.9;carMesh.position.set(carBody.position.x,.45,carBody.position.z);carMesh.rotation.y=yaw;
  camera.position.set(carBody.position.x,carBody.position.y+1.25,carBody.position.z);if(engineGain)engineGain.gain.setTargetAtTime(Math.min(.14,vel*.012),audioCtx.currentTime,.1);if(engineOsc)engineOsc.frequency.setTargetAtTime(45+vel*8,audioCtx.currentTime,.1);
 }
 camera.rotation.order='YXZ';camera.rotation.y=yaw;camera.rotation.x=Math.max(-1.1,Math.min(1.1,pitch));
 for(const t of traffic){t.mesh.position.z+=t.zSpeed*dt*t.dir;if(t.mesh.position.z>120)t.mesh.position.z=-120;if(t.mesh.position.z< -120)t.mesh.position.z=120;}
 const p=new CANNON.Vec3(playerBody.position.x,0,playerBody.position.z);nearby=null;
 for(const c of colliders){if(p.distanceTo(c.pos)<c.radius){nearby=c.kind;break;}}
 $('prompt').style.display=nearby?'block':'none';$('enterCar').style.display=nearby==='car'&&!inCar?'grid':'none';
 if(inCar)$('interact').textContent='↙';else $('interact').textContent='☝';
 if(objectiveStage===1&&p.distanceTo(new CANNON.Vec3(-3,0,-54))<9){$('prompt').style.display='block';$('prompt').textContent='☝  INVESTIGAR TORRE';nearby='tower';}
}
function animate(){
 requestAnimationFrame(animate);const dt=Math.min(clock.getDelta(),.04);
 if(started&&!paused){world.step(1/60,dt,3);update(dt);}
 renderer.render(scene,camera);
}
clock=new THREE.Clock();createWorld();initPhysics();setupControls();settingsUI();
window.addEventListener('resize',()=>{camera.aspect=innerWidth/innerHeight;camera.updateProjectionMatrix();renderer.setSize(innerWidth,innerHeight);});
animate();
