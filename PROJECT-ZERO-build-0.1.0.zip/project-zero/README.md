# PROJECT: ZERO — build 0.1.0

Protótipo jogável 3D em terceira pessoa, pensado primeiro para Android e navegador móvel.

## O que já está nesta primeira fatia
- Cidade noturna original com avenida, prédios modulares detalhados, letreiros luminosos, carros abandonados, postes, caixas técnicas, névoa e torre distante.
- Personagem explorador estilizado construído com peças articuladas, armadura, visor e mochila de rádio.
- Câmera em terceira pessoa, movimentação por teclado e joystick virtual, câmera por arrasto no lado direito da tela.
- Cena de introdução, diálogo com rádio, terminal interativo e progressão de objetivo.
- Menu, pausa, qualidade gráfica, volume e salvamento local.
- Projeto preparado para empacotamento Android com Capacitor.

## Executar no navegador
Requer Node.js 20 ou superior.

```bash
npm install
npm run dev
```

Abra o endereço mostrado pelo Vite. Para compilar os arquivos web:

```bash
npm run build
```

## Preparação Android (com computador)
```bash
npm install
npx cap add android
npm run build
npx cap sync android
```
Depois abra `android/` no Android Studio e gere um APK de teste. O workflow em `.github/workflows/android-apk.yml` também demonstra uma compilação em runner Linux do GitHub Actions, sem exigir que o desenvolvedor tenha um PC local.

## Próxima etapa narrativa
A primeira fatia termina após o terminal transmitir as coordenadas do metrô. A entrada do metrô, o capítulo seguinte, inimigos/sistemas de ameaça, animações completas e modelos GLB finais ainda precisam ser produzidos. Não são apresentados como conteúdo pronto nesta versão.

## Assets e licenças
O cenário e o personagem desta fatia são geometria original criada no código. Nenhum modelo externo foi incluído nesta versão. Para os próximos capítulos, priorizar GLB/GLTF e ativos CC0 com licença conferida individualmente. Poly Haven publica seus ativos sob CC0: https://polyhaven.com/license

## Limitações conhecidas da build 0.1.0
- É uma fatia inicial, não um jogo completo.
- A cidade é uma composição procedural otimizada; ainda não contém modelos de personagens escaneados nem animações cinematográficas finais.
- O som atual é ambiente sintetizado simples; trilha e efeitos profissionais serão adicionados em etapa própria.
- O teste final em aparelhos Android físicos ainda é necessário.
