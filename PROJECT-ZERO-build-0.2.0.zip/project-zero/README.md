# PROJECT: ZERO — Build 0.2.0

Primeira versão de produção jogável (vertical slice), em primeira pessoa.

## O que já está implementado
- Cidade noturna explorável em 3D, com neblina, iluminação, sombras e cenário procedural.
- Câmera em primeira pessoa e controles de teclado/toque com analógico virtual.
- Interação com rádio e veículo; carros de tráfego circulam pela avenida.
- Veículo dirigível com simulação física básica via cannon-es.
- Trilha ambiente original sintetizada por Web Audio e efeitos sonoros originais.
- Menu, pausa, configurações gráficas, sensibilidade, FOV, volume e créditos.
- Objetivo inicial e conclusão do primeiro capítulo.
- Interface adaptada para celular.

## Limites honestos desta build
É um capítulo jogável inicial, não um jogo AAA completo. Os carros usam física simplificada; não há ainda campanha longa, modelos humanos cinematográficos, diálogos ramificados ou assets escaneados de alta fidelidade. A qualidade final depende de testes em aparelhos reais e de substituir partes procedurais por assets 3D licenciados e otimizados. O jogo não usa modelos ou músicas comerciais copiados.

## Rodar localmente
```bash
npm install
npm run dev
```

## Gerar APK
O workflow `PROJECT-ZERO-android-apk.yml` deve ficar em `.github/workflows/` na raiz do repositório. Ele compila um APK debug e publica o APK como artifact no GitHub Actions.
